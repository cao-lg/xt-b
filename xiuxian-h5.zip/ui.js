/* ============================================================
 * 放置修仙 · 逍遥道途 v2 —— 界面渲染与交互
 * ============================================================ */
(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const view = $('#view');
  const modalLayer = $('#modal-layer');
  const toastLayer = $('#toast-layer');

  const REALM_AVATAR = ['🧘', '🧘', '⚪', '👶', '🌌', '🌠', '🔗', '🚀', '⚡', '✨'];
  let currentTab = 'cultivate';
  let currentMap = 'yaolin';
  let currentLevel = 0;
  let battleMode = 'map'; // 'map' | 'tower'

  // 自动跳到最后通过的关卡：找到最后一个有进度的地图
  function autoSelectLastCleared() {
    const s = Game.state;
    let lastMap = null;
    for (let i = Game.MAPS.length - 1; i >= 0; i--) {
      const m = Game.MAPS[i];
      if (s.mapProgress[m.id] !== undefined) { lastMap = m; break; }
    }
    if (lastMap) {
      currentMap = lastMap.id;
      currentLevel = Math.max(0, s.mapProgress[lastMap.id] || 0);
    }
  }

  // 难度评级（基于玩家战力与敌人推荐战力对比）
  function difficultyRating(enemy, playerPower) {
    const ep = Math.floor(enemy.atk * 2 + enemy.def * 1.5 + enemy.hp * 0.25);
    if (playerPower <= 0) return { text: '?', cls: 'diff-unk' };
    const ratio = playerPower / ep;
    if (ratio >= 20) return { text: '碾', cls: 'diff-easy' };
    if (ratio >= 8) return { text: '简', cls: 'diff-easy' };
    if (ratio >= 3) return { text: '普', cls: 'diff-norm' };
    if (ratio >= 1.5) return { text: '难', cls: 'diff-hard' };
    if (ratio >= 0.8) return { text: '险', cls: 'diff-hard' };
    if (ratio >= 0.4) return { text: '绝', cls: 'diff-dead' };
    return { text: '死', cls: 'diff-dead' };
  }

  /* ---------------- 工具 ---------------- */
  function relTime(t) {
    const s = Math.floor((Date.now() - t) / 1000);
    if (s < 60) return '刚刚';
    if (s < 3600) return Math.floor(s / 60) + '分前';
    if (s < 86400) return Math.floor(s / 3600) + '时前';
    return Math.floor(s / 86400) + '天前';
  }
  function toast(msg, gold) {
    const el = document.createElement('div');
    el.className = 'toast' + (gold ? ' gold' : '');
    el.textContent = msg;
    toastLayer.appendChild(el);
    setTimeout(() => el.remove(), 2700);
  }
  function floatNum(text, x, y) {
    const el = document.createElement('div');
    el.className = 'float-num'; el.textContent = text;
    el.style.left = x + 'px'; el.style.top = y + 'px';
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 950);
  }
  function modal(html, cls) {
    const mask = document.createElement('div');
    mask.className = 'modal-mask' + (cls ? ' ' + cls : '');
    mask.innerHTML = `<div class="modal">${html}</div>`;
    modalLayer.appendChild(mask);
    return mask;
  }
  function closeModal(mask) { mask.remove(); }

  /* ---------------- 顶栏 / 动态数值 ---------------- */
  function updateTopbar() {
    const s = Game.state;
    const realm = Game.REALMS[s.realmIndex];
    $('#realm-emoji').textContent = REALM_AVATAR[s.realmIndex] || '🧘';
    $('#dao-name').textContent = s.daoName;
    $('#realm-name').textContent = `${realm.name} · ${Game.CHINESE_LAYER[s.layer]}层`;
    const cost = Game.breakCost();
    const ratio = cost > 0 ? s.xp / cost : 0;
    $('#xp-val').textContent = Game.formatNum(s.xp);
    $('#xp-need').textContent = Game.formatNum(cost);
    $('#stone-val').textContent = Game.formatNum(s.stone);
    $('#speed-val').textContent = Game.formatSpeed(Game.currentSpeed());
    $('#progress-bar').style.width = Math.min(100, ratio * 100) + '%';
    $('#progress-pct').textContent = Math.min(100, Math.floor(ratio * 100)) + '%';
    const bb = $('#btn-break');
    if (bb) { const ready = Game.canBreak(); bb.classList.toggle('ready', ready); bb.disabled = !ready; }
    const bl = $('#buff-line'); if (bl) bl.innerHTML = buildBuffLine();
  }

  function buildBuffLine() {
    const s = Game.state;
    let html = '';
    Game.PILLS.forEach(p => { const left = s.pills[p.id] || 0; if (left > 0) html += `<span class="pill-tag" title="${p.desc}，剩余 ${Game.formatTime(left)}">${p.icon} ${p.name} ${Game.formatTime(left)}</span>`; });
    const tm = Game.techniqueMult(); const ab = Game.abodeBonus(); const pa = Game.petAllBonus();
    if (tm > 1) html += `<span class="pill-tag" title="功法总和：修炼速度 ×${tm.toFixed(2)}，战斗：攻×${tm.toFixed(2)} 防/血×${(1+CONFIG.combat.techShare*(tm-1)).toFixed(2)}">📜 功法 +${Math.round((tm - 1) * 100)}%</span>`;
    if (ab > 0) html += `<span class="pill-tag" title="灵气浓度：修炼+${Math.round(ab*100)}%，战斗：防/血×${(1+ab*CONFIG.combat.abodeCombat).toFixed(2)}">⛰️ 灵气 +${Math.round(ab * 100)}%</span>`;
    if (pa > 0) html += `<span class="pill-tag" title="獬豸全资源加成：修炼+${Math.round(pa*100)}%，战斗：攻/防/血×${(1+pa*CONFIG.combat.petAllCombat).toFixed(2)}">🦄 灵宠 +${Math.round(pa * 100)}%</span>`;
    if (s.legacy > 0) html += `<span class="pill-tag" title="仙缘倍率：攻/防/血 ×${Game.legacyMult().toFixed(2)}">🔁 仙缘 +${Math.round(s.legacy * CONFIG.legacyPerPoint * 100)}%</span>`;
    return html || '<span style="color:var(--text-dim)">运转周天，静心修炼……</span>';
  }

  /* ---------------- 修炼页 ---------------- */
  function renderCultivate() {
    const s = Game.state;
    const major = Game.isMajorBreak();
    const breakTxt = major ? '⚡ 渡劫飞升' : '🌀 破境晋升';
    const trib = major ? `<div class="cd-text" style="color:var(--jade);margin-top:8px">渡劫成功率 ${Math.round(Game.tribChance() * 100)}%${s.pills.bijie > 0 ? '（避劫丹·必成）' : ''}</div>` : '';
    view.innerHTML = `
      <div class="cultivate-stage">
        <div class="avatar-glow"><div class="avatar">${REALM_AVATAR[s.realmIndex] || '🧘'}</div></div>
        <div class="buff-line" id="buff-line">${buildBuffLine()}</div>
        <button class="btn" id="btn-cultivate">🧘 运转周天（手动修炼）</button>
        <button class="btn btn-break" id="btn-break">${breakTxt}</button>
        ${trib}
        <div class="hint">
          修为攒满即可<b>破境</b>；跨大境界需<b>渡劫飞升</b>，有成功率与风险。<br/>
          功法/洞府/灵宠永久加成，丹药限时暴涨，秘境/悟道拓展道途，飞升转世得仙缘。
        </div>
      </div>`;
    $('#btn-cultivate').addEventListener('click', (e) => {
      const r = Game.clickCultivate();
      const rect = e.currentTarget.getBoundingClientRect();
      floatNum('+' + Game.formatNum(r.gain) + ' 修为', rect.left + rect.width / 2 - 30, rect.top - 10);
    });
    $('#btn-break').addEventListener('click', () => { if (Game.canBreak()) Game.doBreak(); });
  }

  /* ---------------- 功法 / 洞府 / 丹药 ---------------- */
  function renderTechniques() {
    const s = Game.state;
    const cards = Game.TECHNIQUES.map(t => {
      const lv = s.techniques[t.id] || 0, maxed = lv >= t.max, price = Game.techniquePrice(t.id), afford = s.stone >= price && !maxed;
      const bonus = lv > 0 ? `当前加成 +${Math.round(t.mult * lv * 100)}%` : '尚未修习';
      const btn = maxed ? `<button class="buy-btn maxed" disabled>圆满</button>`
        : `<button class="buy-btn" data-buy="technique" data-id="${t.id}" ${afford ? '' : 'disabled'}>修习<div class="price">${Game.formatNum(price)} 💎</div></button>`;
      return `<div class="card"><div class="icon">${t.icon}</div><div class="body"><div class="name">${t.name} <span class="lv">${lv}/${t.max} 层</span></div><div class="desc">${t.desc}</div><div class="sub">${bonus}</div></div>${btn}</div>`;
    }).join('');
    view.innerHTML = `<div class="section-title">📜 功法 <small>消耗灵石，永久提升修炼速度</small></div><div class="list">${cards}</div>`;
    bindBuy('technique');
  }
  function renderAbodes() {
    const s = Game.state;
    const cards = Game.ABODES.map(a => {
      const lv = s.abodes[a.id] || 0, maxed = lv >= a.max, price = Game.abodePrice(a.id), afford = s.stone >= price && !maxed;
      const bonus = lv > 0 ? `灵气浓度 +${Math.round(a.mult * lv * 100)}%` : '未开拓';
      const btn = maxed ? `<button class="buy-btn maxed" disabled>圆满</button>`
        : `<button class="buy-btn" data-buy="abode" data-id="${a.id}" ${afford ? '' : 'disabled'}>拓建<div class="price">${Game.formatNum(price)} 💎</div></button>`;
      return `<div class="card"><div class="icon">${a.icon}</div><div class="body"><div class="name">${a.name} <span class="lv">${lv}/${a.max} 重</span></div><div class="desc">${a.desc}</div><div class="sub">${bonus}</div></div>${btn}</div>`;
    }).join('');
    view.innerHTML = `<div class="section-title">⛰️ 洞府 <small>提升灵气浓度，乘法加成修炼</small></div><div class="list">${cards}</div>`;
    bindBuy('abode');
  }
  function renderPills() {
    const s = Game.state;
    const cards = Game.PILLS.map(p => {
      const left = s.pills[p.id] || 0, afford = s.stone >= p.baseStone;
      const status = left > 0 ? `<div class="sub">生效中 · 剩余 ${Game.formatTime(left)}</div>` : '';
      const btn = `<button class="buy-btn" data-buy="pill" data-id="${p.id}" ${afford ? '' : 'disabled'}>服用<div class="price">${Game.formatNum(p.baseStone)} 💎</div></button>`;
      return `<div class="card"><div class="icon">${p.icon}</div><div class="body"><div class="name">${p.name}</div><div class="desc">${p.desc}</div>${status}</div>${btn}</div>`;
    }).join('');
    view.innerHTML = `<div class="section-title">💊 丹药 <small>服下后限时暴涨修炼速度</small></div><div class="list">${cards}</div>`;
    bindBuy('pill');
  }

  /* ---------------- 灵宠 ---------------- */
  function renderPet() {
    const s = Game.state;
    const seek = Game.seekCost();
    const seekAfford = s.stone >= seek;
    const seekBtn = `<button class="btn" id="btn-seek" ${seekAfford ? '' : 'disabled'}>🐾 寻妖（${Game.formatNum(seek)} 💎）</button>`;
    const cards = Game.PETS.map(p => {
      const lv = s.pets[p.id] || 0;
      const perLv = p.produce.base * lv;          // 该灵宠本等级基础产率
      const perSec = perLv * Game.legacyMult() * (1 + Game.petAllBonus()); // 计入仙缘 / 全资源加成后的真实每秒产出
      const out = (p.produce.type === 'all')
        ? `全资源加成 +${Math.round(perLv * 100)}%`
        : `产出 ${fmtAmt(perSec)} ${typeUnit(p.produce.type)}/秒`;
      const feed = Game.feedCost(p.id), fAfford = lv > 0 && s.materials >= feed;
      const fbtn = lv <= 0 ? `<span class="sub">尚未收服</span>`
        : `<button class="buy-btn" data-feed="${p.id}" ${fAfford ? '' : 'disabled'}>喂养<div class="price">${feed} 🌿</div></button>`;
      return `<div class="card"><div class="icon">${p.icon}</div><div class="body"><div class="name">${p.name} <span class="lv">${lv} 级</span></div><div class="desc">${p.desc}</div><div class="sub">${out}</div></div>${fbtn}</div>`;
    }).join('');
    view.innerHTML = `
      <div class="section-title">🐾 灵宠 <small>寻妖收服，喂养升级，自动产出</small></div>
      <div class="res-bar"><div class="res-chip mat"><div class="l">天材地宝</div><div class="v">🌿 ${Game.formatNum(s.materials)}</div></div></div>
      <div class="hint">🌿 <b>天材地宝</b>：喂养灵宠、强化法宝的核心素材。寻妖（重复收服赠予）、秘境、奇遇、战斗、熔炼盈余法宝皆可得。</div>
      ${seekBtn}
      <div class="list" style="margin-top:12px">${cards}</div>`;
    $('#btn-seek').addEventListener('click', () => { if (Game.seekPet()) renderCurrent(); else toast('灵石不足'); });
    view.querySelectorAll('[data-feed]').forEach(b => b.addEventListener('click', () => { if (Game.feedPet(b.dataset.feed)) renderCurrent(); else toast('天材地宝不足'); }));
  }
  function typeUnit(t) { return t === 'xp' ? '修为' : t === 'stone' ? '灵石' : '🌿'; }
  // 小数安全的数值格式：小于 1 时保留两位小数（避免 formatNum 直接取整为 0）
  function fmtAmt(v) { return v < 1 ? (+v).toFixed(2) : Game.formatNum(v); }

  /* ---------------- 战斗 / 法宝 辅助 ---------------- */
  function qName(q) { const Q = Game.QUALITY.find(x => x.id === q); return Q ? Q.name : ''; }
  function qColor(q) { const Q = Game.QUALITY.find(x => x.id === q); return Q ? Q.color : '#fff'; }
  function slotName(slot) { return slot === 'weapon' ? '攻伐' : slot === 'armor' ? '守护' : '辅助'; }
  function attrText(a) {
    const m = { atk: '攻', def: '防', hp: '气血', hit: '命中', dodge: '闪避', crit: '暴击' };
    const parts = [];
    for (const k in a) {
      if (k === 'hit' || k === 'dodge' || k === 'crit') parts.push(`${m[k]}+${Math.round(a[k] * 100)}%`);
      else parts.push(`${m[k]}+${Math.round(a[k])}`);
    }
    return parts.join(' · ');
  }
  function isMapUnlocked(mapId) {
    const mi = Game.MAPS.findIndex(m => m.id === mapId);
    if (mi === 0) return true;
    const prev = Game.MAPS[mi - 1];
    const pc = Game.state.mapProgress[prev.id];
    return pc !== undefined && pc >= prev.levels.length - 1;
  }

  /* ---------------- 秘境 ---------------- */
  function renderSecret() {
    const s = Game.state;
    const cd = !Game.canExplore();
    const cards = Game.SECRET_REALMS.map(r => {
      const afford = s.stone >= r.cost;
      const btn = `<button class="buy-btn" data-explore="${r.id}" ${afford && !cd ? '' : 'disabled'}>探索<div class="price">${Game.formatNum(r.cost)} 💎</div></button>`;
      return `<div class="card"><div class="icon">${r.icon}</div><div class="body"><div class="name">${r.name}</div><div class="desc">修为${Game.formatNum(r.xp[0])}~${Game.formatNum(r.xp[1])} · 灵石${Game.formatNum(r.stone[0])}~${Game.formatNum(r.stone[1])} · 🌿${r.mat[0]}~${r.mat[1]}</div><div class="sub">风险 ${Math.round(r.risk * 100)}%（损修为 ${Math.round(r.riskLoss * 100)}%）</div></div>${btn}</div>`;
    }).join('');
    const cdText = cd ? `<div class="cd-text">秘境冷却中……</div>` : '';
    view.innerHTML = `<div class="section-title">🗺️ 秘境历练 <small>耗灵石探索，得资源亦有机危</small></div>${cdText}<div class="list">${cards}</div>`;
    view.querySelectorAll('[data-explore]').forEach(b => b.addEventListener('click', () => {
      if (Game.explore(b.dataset.explore)) renderCurrent(); else toast('灵石不足或冷却中');
    }));
  }

  /* ---------------- 悟道 ---------------- */
  function renderInsight() {
    const s = Game.state;
    const cards = Game.INSIGHTS.map(i => {
      const lv = s.insightLv[i.id] || 0, maxed = lv >= i.max, price = Game.insightPrice(i.id), afford = s.insight >= price && !maxed;
      const bonus = lv > 0 ? `当前 +${Math.round(i.mult * lv * 100)}%` : '未参悟';
      const btn = maxed ? `<button class="buy-btn maxed" disabled>圆满</button>`
        : `<button class="buy-btn" data-insight="${i.id}" ${afford ? '' : 'disabled'}>参悟<div class="price">${price} 📿</div></button>`;
      return `<div class="card"><div class="icon">${i.icon}</div><div class="body"><div class="name">${i.name} <span class="lv">${lv}/${i.max} 重</span></div><div class="desc">${i.desc}</div><div class="sub">${bonus}</div></div>${btn}</div>`;
    }).join('');
    view.innerHTML = `
      <div class="section-title">📿 悟道 <small>以悟性点参悟，永久提升</small></div>
      <div class="res-bar"><div class="res-chip insight"><div class="l">悟性点</div><div class="v">📿 ${Game.formatNum(s.insight)}</div></div></div>
      <div class="list">${cards}</div>`;
    view.querySelectorAll('[data-insight]').forEach(b => b.addEventListener('click', () => { if (Game.comprehend(b.dataset.insight)) renderCurrent(); else toast('悟性点不足'); }));
  }

  /* ---------------- 飞升转生 ---------------- */
  function renderFly() {
    const s = Game.state;
    const can = Game.canReincarnate();
    const gain = Game.legacyGain();
    const hero = can
      ? `<div class="fly-hero"><div class="big">🔁 可飞升转世</div><div class="sub">飞升后将重置修为/境界/功法/洞府/灵宠，<br/>但<b>灵根·悟道·仙缘</b>永久保留。<br/>本次可得仙缘 <b>+${gain}</b>（全局效率 +${Math.round(gain * CONFIG.legacyPerPoint * 100)}%）。<br/>已飞升 ${s.reincarnations} 次。</div>
         <button class="btn btn-fly ready" id="btn-fly">飞升转世</button></div>`
      : `<div class="fly-hero"><div class="big">🔒 尚未圆满</div><div class="sub">需先证得<b>真仙</b>（当前 ${Game.REALMS[s.realmIndex].name}）。<br/>飞升后可携仙缘重入轮回，愈发强盛。</div></div>`;
    view.innerHTML = `
      <div class="res-bar">
        <div class="res-chip legacy"><div class="l">仙缘</div><div class="v">🔁 ${Game.formatNum(s.legacy)}</div></div>
        <div class="res-chip legacy"><div class="l">全局加成</div><div class="v">+${Math.round(s.legacy * CONFIG.legacyPerPoint * 100)}%</div></div>
      </div>
      ${hero}`;
    const bf = $('#btn-fly');
    if (bf) bf.addEventListener('click', () => { if (Game.reincarnate()) renderCurrent(); });
  }

  /* ---------------- 奇遇 / 成就 / 设置 ---------------- */
  function renderEvents() {
    const s = Game.state;
    if (!s.log.length) { view.innerHTML = `<div class="section-title">📖 奇遇</div><div class="empty">尚无功法缘法，静待机缘……</div>`; return; }
    const items = s.log.map(l => `<div class="log-item"><div class="icon">${l.icon || '📜'}</div><div><div>${l.text}</div><div class="time">${relTime(l.t)}</div></div></div>`).join('');
    view.innerHTML = `<div class="section-title">📖 修行情缘 <small>历练中偶遇的机缘</small></div><div class="list">${items}</div>`;
  }
  function renderAchievements() {
    const s = Game.state;
    const cards = Game.ACHIEVEMENTS.map(a => {
      const unlocked = !!s.achievements[a.id];
      return `<div class="card achv-card ${unlocked ? 'unlocked' : ''}"><div class="icon">${unlocked ? a.icon : '🔒'}</div><div class="body"><div class="name">${a.name}</div><div class="desc">${a.desc}</div><div class="sub">${unlocked ? '已达成' : '未达成'}</div></div></div>`;
    }).join('');
    const got = Object.keys(s.achievements).length;
    view.innerHTML = `<div class="section-title">🏆 成就 <small>${got}/${Game.ACHIEVEMENTS.length} 已解锁</small></div><div class="list">${cards}</div>`;
  }
  function renderSettings() {
    const s = Game.state;
    const playSec = (Date.now() - s.startTime) / 1000;
    view.innerHTML = `
      <div class="section-title">⚙️ 设置</div>
      <div class="setting-block"><h3>道号</h3><div class="field"><input id="dao-input" maxlength="12" value="${s.daoName}" /><button class="btn-sm" id="dao-save">保存</button></div></div>
      <div class="setting-block"><h3>道途纪要</h3><div class="stat-grid">
        <div class="cell"><b>${Game.formatNum(s.totalXp)}</b><span>累计修为</span></div>
        <div class="cell"><b>${s.breaks}</b><span>破境次数</span></div>
        <div class="cell"><b>${Game.formatTime(playSec)}</b><span>修行时长</span></div>
        <div class="cell"><b>${s.reincarnations}</b><span>飞升次数</span></div>
        <div class="cell"><b>${Game.formatNum(Game.combatStats().power)}</b><span>战力</span></div>
        <div class="cell"><b>${s.bossKills}</b><span>伏魔数</span></div>
        <div class="cell"><b>${Game.formatNum(s.legacy)}</b><span>仙缘</span></div>
        <div class="cell"><b>${Game.formatNum(s.insight)}</b><span>悟性点</span></div>
      </div></div>
      <div class="setting-block"><h3>存档</h3><div class="field" style="margin-bottom:10px"><button class="btn-sm" id="manual-save" style="flex:1;padding:10px">立即存档</button></div>
        <div class="hint" style="text-align:left">游戏自动存档于本地浏览器，关闭网页亦不丢失；离线期间仍以半数效率修行（封顶 ${CONFIG.offlineCapHours} 时辰）。</div></div>
      <div class="setting-block"><h3>战斗音效</h3>
        <div class="field"><label style="display:flex;align-items:center;gap:8px;cursor:pointer">
          <input type="checkbox" id="sfx-tgl" ${s.sfx?'checked':''} onchange="Game.state.sfx=this.checked;Game.save();SFX.setEnabled(this.checked)"/>
          <span>启用回合制战斗音效（Web Audio 合成，无音频文件）</span>
        </label></div></div>
      <div class="setting-block"><h3>重入轮回</h3><button class="btn-danger" id="btn-reset">抹去此世修行记录</button>
        <div class="hint" style="text-align:left;margin-top:8px">此举将清空全部进度，且不可恢复。</div></div>`;
    $('#dao-save').addEventListener('click', () => { Game.setDaoName($('#dao-input').value); toast('道号已更易', true); });
    $('#manual-save').addEventListener('click', () => { Game.save(); toast('已存档'); });
    $('#btn-reset').addEventListener('click', () => {
      const m = modal(`<h2>⚠ 重入轮回</h2><p>此操作将抹去全部道途，确定否？</p>
        <button class="btn btn-danger" id="confirm-reset" style="margin-top:8px">斩断因果</button>
        <button class="btn" id="cancel-reset" style="margin-top:10px;background:rgba(120,140,190,0.2);color:#fff;box-shadow:none">再思量</button>`, 'tribulation');
      $('#confirm-reset').addEventListener('click', () => { Game.reset(); closeModal(m); switchTab('cultivate'); toast('道途重启'); });
      $('#cancel-reset').addEventListener('click', () => closeModal(m));
    });
  }

  /* ---------------- 战斗（历练） ---------------- */
  function renderBattle() {
    const s = Game.state;
    // 首次进入（或没手动选过）时跳到最后通关的关卡
    if (!s._battleUserSelected) autoSelectLastCleared();
    const st = Game.combatStats();
    const cd = !Game.canBattle();
    const maps = Game.MAPS;
    const mapTabs = maps.map(m => {
      const unlocked = isMapUnlocked(m.id);
      const cleared = s.mapProgress[m.id] !== undefined && s.mapProgress[m.id] >= m.levels.length - 1;
      return `<button class="map-tab ${battleMode === 'map' && m.id === currentMap ? 'active' : ''} ${unlocked ? '' : 'locked'}" data-map="${m.id}" ${unlocked ? '' : 'disabled'}>${unlocked ? m.icon : '🔒'} ${m.name}${cleared ? ' ✓' : ''}</button>`;
    }).join('');
    const towerTab = `<button class="map-tab ${battleMode === 'tower' ? 'active' : ''}" data-mode="tower">🗼 无尽塔</button>`;
    const cdText = cd ? `<div class="cd-text">⏳ 调息中… 还需 ${Game.battleCooldownLeft()} 秒</div>` : '';
    let body = '';
    if (battleMode === 'tower') {
      const next = s.towerFloor + 1;
      const d = (CONFIG.combat.towerBase + next * CONFIG.combat.towerStep).toFixed(2);
      const preview = Game.towerEnemy(next);
      const xp = Math.floor((Game.currentSpeed ? Game.currentSpeed() : 0) * (preview.boss ? 24 : 8) * (CONFIG.combat.towerBase + next * CONFIG.combat.towerStep));
      const ep = Math.floor(preview.atk * 2 + preview.def * 1.5 + preview.hp * 0.25);
      const diff = difficultyRating(preview, st.power);
      body = `
        <div class="tower-view">
          <div class="tower-info">当前最高层 <b>${s.towerFloor}</b> · 下一层 <b>${next}</b> · 难度 ×${d} · 推荐战力 <b>${Game.formatNum(ep)}</b> · 难度 <span class="${diff.cls}">${diff.text}</span></div>
          <div class="level-row">
            <div class="level-idx">🗼</div>
            <div class="level-body">
              <div class="name">${preview.icon} ${preview.name} ${preview.boss ? '<span class="boss-tag">BOSS</span>' : ''}</div>
              <div class="enemy-stats">攻${preview.atk} 防${preview.def} 气血${preview.hp} 命中${Math.round(preview.hit * 100)}% 闪避${Math.round(preview.dodge * 100)}% 暴击${Math.round(preview.crit * 100)}%</div>
              <div class="reward-line">奖励 灵石${Game.formatNum(preview.reward.stone[0])}~${Game.formatNum(preview.reward.stone[1])} · 🌿${preview.reward.mat[0]}~${preview.reward.mat[1]} · 修为 ≈ ${Game.formatNum(xp)} · 法宝掉落${Math.round(preview.drop.chance * 100)}%</div>
            </div>
            <button class="buy-btn fight-btn" data-tower="${next}" ${cd ? 'disabled' : ''}>挑战</button>
          </div>
        </div>`;
    } else {
      const map = maps.find(m => m.id === currentMap);
      const levels = map.levels.map((lv, i) => {
        const unlocked = Game.isLevelUnlocked(map.id, i);
        const cleared = s.mapProgress[map.id] !== undefined && s.mapProgress[map.id] >= i;
        const isCurrent = i === currentLevel;
        const lockText = (map.realmReq !== undefined && s.realmIndex < map.realmReq) ? '需' + Game.REALMS[map.realmReq].name : '🔒 未解锁';
        const btn = unlocked
          ? `<button class="buy-btn fight-btn" data-fight="${map.id}:${i}" ${cd ? 'disabled' : ''}>${cleared ? '再战' : '挑战'}</button>`
          : `<button class="buy-btn" disabled>${lockText}</button>`;
        const ep = Math.floor(lv.atk * 2 + lv.def * 1.5 + lv.hp * 0.25);
        const diff = difficultyRating(lv, st.power);
        return `<div class="level-row ${cleared ? 'cleared' : ''} ${unlocked ? '' : 'locked'} ${isCurrent ? 'current' : ''}">
          <div class="level-idx">${i + 1}</div>
          <div class="level-body">
            <div class="name">${lv.icon} ${lv.name} ${lv.boss ? '<span class="boss-tag">BOSS</span>' : ''} ${cleared ? '<span class="cleared-tag">已通关</span>' : ''} <span class="${diff.cls}" title="推荐战力 ${Game.formatNum(ep)} / 你的战力 ${Game.formatNum(st.power)}">难度 ${diff.text}</span></div>
            <div class="enemy-stats">攻${lv.atk} 防${lv.def} 气血${lv.hp} 命中${Math.round(lv.hit * 100)}% 闪避${Math.round(lv.dodge * 100)}% 暴击${Math.round(lv.crit * 100)}% · 推荐战力 ${Game.formatNum(ep)}</div>
            <div class="reward-line">奖励 灵石${Game.formatNum(lv.reward.stone[0])}~${Game.formatNum(lv.reward.stone[1])} · 🌿${lv.reward.mat[0]}~${lv.reward.mat[1]} · 修为 ≈ ${Game.formatNum(Math.floor((Game.currentSpeed ? Game.currentSpeed() : 0) * (lv.boss ? 18 : 6)))}${lv.drop && lv.drop.chance ? ` · 法宝掉落${Math.round(lv.drop.chance * 100)}%` : ''}</div>
          </div>${btn}</div>`;
      }).join('');
      body = `<div class="map-desc">${map.desc}</div>${cdText}<div class="level-path">${levels}</div>`;
    }
    view.innerHTML = `
      <div class="section-title">⚔️ 历练 · 战斗 <small>回合制对战，命中/闪避/暴击皆随机</small></div>
      <div class="player-panel">
        <div class="pp-head">🧘 自身战力 <b>${Game.formatNum(st.power)}</b></div>
        <div class="pp-stats">
          <span>攻 ${st.atk}</span><span>防 ${st.def}</span><span>气血 ${st.hp}</span>
          <span>命中 ${Math.round(st.hit * 100)}%</span><span>闪避 ${Math.round(st.dodge * 100)}%</span><span>暴击 ${Math.round(st.crit * 100)}%</span>
        </div>
        <div class="hint" style="margin-top:8px">攻/防/气血/命中/闪避/暴击 受功法、洞府、丹药、悟道、灵宠、灵根、仙缘、法宝共同影响。</div>
        <details class="breakdown" style="margin-top:8px;font-size:12px;color:var(--text-dim)">
          <summary>📊 各系统战斗属性贡献详情</summary>
          <div style="padding:8px 0 4px 8px;line-height:1.7;color:var(--gold-soft)">${Game.combatFormula().map(l=>`<div>${l}</div>`).join('')}</div>
          <div style="padding:4px 0 4px 8px;line-height:1.7;border-top:1px dashed rgba(120,140,190,0.2);margin-top:6px">${Game.combatBreakdown().map(i => `<div title="${i.desc}"><span>${i.icon} ${i.name}</span><span style="float:right;color:var(--text)">${i.desc}</span></div>`).join('')}</div>
        </details>
      </div>
      <div class="map-tabs">${mapTabs}${towerTab}</div>
      ${body}`;
    view.querySelectorAll('[data-map]').forEach(b => b.addEventListener('click', () => { if (!b.disabled) { battleMode = 'map'; currentMap = b.dataset.map; currentLevel = 0; Game.state._battleUserSelected = true; renderBattle(); } }));
    view.querySelectorAll('[data-mode="tower"]').forEach(b => b.addEventListener('click', () => { battleMode = 'tower'; Game.state._battleUserSelected = true; renderBattle(); }));
    view.querySelectorAll('[data-fight]').forEach(b => b.addEventListener('click', () => {
      const [mid, idx] = b.dataset.fight.split(':');
      currentLevel = parseInt(idx, 10);
      Game.state._battleUserSelected = true;
      const r = Game.fight(mid, currentLevel);
      if (!r) return;
      if (r.error === 'locked') { toast('关卡尚未解锁'); return; }
      if (r.error === 'cd') { toast('调息中，稍后再战'); return; }
      showCombat(r); renderBattle();
    }));
    view.querySelectorAll('[data-tower]').forEach(b => b.addEventListener('click', () => {
      Game.state._battleUserSelected = true;
      const floor = parseInt(b.dataset.tower, 10);
      const r = Game.towerFight(floor);
      if (!r) return;
      if (r.error === 'locked') { toast('塔层尚未解锁'); return; }
      if (r.error === 'cd') { toast('调息中，稍后再战'); return; }
      showCombat(r); renderBattle();
    }));
    // 滚到最后通过的关卡
    setTimeout(() => {
      const cur = view.querySelector('.level-row.current');
      if (cur) cur.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }, 50);
  }
  // 取玩家等级最高的功法作为「本命功法」，决定施法光环色
  const TECH_ELEMENT = { tuna: '#6fcf97', yinqi: '#56ccf2', zhoutian: '#aab7ff', wuxing: '#f2c94c', taiyi: '#f2994a', hongmeng: '#bb6bd9' };
  function topTechnique() {
    const techs = Game.state.techniques || {}; let best = null, bestLv = 0;
    Game.TECHNIQUES.forEach(t => { const lv = techs[t.id] || 0; if (lv > bestLv) { bestLv = lv; best = t; } });
    return best;
  }
  function showCombat(r) {
    var A = window.ART; if (!A) { toast('美术资源未加载'); return; }
    var lv = r.level, res = r.res;
    var pHp0 = res.player.hp, eHp0 = res.enemy.hp;
    var tech = topTechnique();
    var aura = tech ? (TECH_ELEMENT[tech.id] || '#9fd0ff') : '#9fd0ff';
    var techName = tech ? tech.icon + tech.name : '🌀 道法';
    var techEl = tech ? (A.elementOf(tech.id) || 'cycle') : 'cycle';  // 玩家本命功法对应的施法元素
    var th = A.theme(lv._mapId || currentMap);
    var pPow = res.player.power, ePow = Math.floor(lv.atk * 2 + lv.def * 1.5 + lv.hp * 0.25);
    var totalPow = Math.max(1, pPow + ePow), pPct = (pPow / totalPow * 100).toFixed(1), ePct = (ePow / totalPow * 100).toFixed(1);
    var lines = res.log.slice(0, 18).map(function(e) {
      if (e.miss) return '<div class="cl '+e.side+'">'+(e.side==='p'?'你':'敌')+' 落空/被闪避…</div>';
      return '<div class="cl '+e.side+'">'+(e.side==='p'?'你':'敌')+' 造成 '+e.dmg+(e.crit?' 💥暴击':'')+'</div>';
    }).join('');
    var more = res.log.length>18 ? '<div class="cl">…共 '+res.log.length+' 回合</div>' : '';
    var rewardHtml = '';
    if (r.win&&r.reward) rewardHtml='<div class="reward">战利品：灵石+'+Game.formatNum(r.reward.stone)+' 🌿+'+r.reward.mat+' 修为+'+Game.formatNum(r.reward.xp)+'</div>';
    if (r.win&&r.drop) rewardHtml+='<div class="reward drop">获得法宝 '+r.drop.icon+r.drop.name+' <span style="color:'+qColor(r.drop.quality)+'">'+qName(r.drop.quality)+'</span>'+(r.drop.first?'（新）':'')+'</div>';
    var m = modal(
      '<h2 class="'+(r.win?'win':'lose')+'">'+lv.icon+' '+(r.win?'胜！':'败')+'</h2>'+
      '<div class="battle-stage" style="--aura:'+aura+';--accent:'+th.accent+';--fig:'+th.fig+';--fig2:'+th.fig2+';--particle:'+th.particle+';--bg:'+th.bg+';--ground:'+th.ground+'">'+
        '<div class="scene-bg"></div>'+
        '<div class="vs-intro"><span>VS</span></div>'+
        '<div class="bars">'+
          '<div class="hpbar p"><div class="hp-fill p" style="width:100%"></div><span class="hp-label" data-plabel>气血 '+pHp0+'</span></div>'+
          '<div class="hpbar e"><div class="hp-fill e" style="width:100%"></div><span class="hp-label" data-elabel>'+lv.name+' '+eHp0+'</span></div>'+
        '</div>'+
        '<div class="powerbar"><span class="pw-p">战力 '+Game.formatNum(pPow)+'</span><div class="pw-track"><div class="pw-fill p" style="width:'+pPct+'%"></div><div class="pw-fill e" style="width:'+ePct+'%"></div></div><span class="pw-e">强度 '+Game.formatNum(ePow)+'</span></div>'+
        '<div class="arena">'+
          '<div class="fighter p">'+A.playerSVG()+'<div class="aura"></div><div class="fname">你</div></div>'+
          '<div class="fighter e'+(lv.boss?' boss':'')+'">'+A.monsterSVG(lv._mapId||currentMap,!!lv.boss)+(lv.boss?'<div class="crown-tag">👑</div>':'')+'<div class="fname">'+lv.name+'</div></div>'+
        '</div>'+
        '<div class="skill-banner">施放 · '+techName+'</div>'+
        '<div class="fx-layer"></div>'+
        '<div class="seal '+(r.win?'win':'lose')+'" style="display:none"><span>'+(r.win?'胜':'败')+'</span></div>'+
      '</div>'+
      '<div class="combat-sub">'+lv.name+' · 回合 '+res.rounds+' · 你剩余气血 <span data-pend>'+pHp0+'</span></div>'+
      '<div class="combat-log">'+lines+more+'</div>'+
      '<div class="combat-reward" style="display:none">'+rewardHtml+'</div>'+
      '<button class="btn" id="cb-ok" style="display:none">收剑</button>', 'combat');
    $('#cb-ok').addEventListener('click',function(){closeModal(m)});
    playBattle(res,lv,m,aura,techEl);
    return m;
  }
  // 逐回合回放战斗 log，驱动 SVG 卡通演出：弹道 / 粒子 / BOSS 二阶段 / 胜负印章 / 音效
  function playBattle(res, lv, m, aura, techEl) {
    var A=window.ART, S=window.SFX, stage=m.querySelector('.battle-stage');
    var pFill=stage.querySelector('.hp-fill.p'), eFill=stage.querySelector('.hp-fill.e');
    var pLabel=stage.querySelector('[data-plabel]'), eLabel=stage.querySelector('[data-elabel]');
    var pFighter=stage.querySelector('.fighter.p'), eFighter=stage.querySelector('.fighter.e');
    var fx=stage.querySelector('.fx-layer'), banner=stage.querySelector('.skill-banner');
    var pAura=pFighter.querySelector('.aura'), seal=stage.querySelector('.seal');
    var log=res.log, pHp0=res.player.hp, eHp0=res.enemy.hp;
    var pHp=pHp0, eHp=eHp0, i=0, phased=false, castCount=0;
    var delay=Math.max(110,Math.min(400,6500/Math.max(1,log.length)));
    function sh(){pFill.style.width=Math.max(0,pHp/pHp0*100)+'%';eFill.style.width=Math.max(0,eHp/eHp0*100)+'%';pLabel.textContent='气血 '+Math.max(0,Math.round(pHp));eLabel.textContent=lv.name+' '+Math.max(0,Math.round(eHp));var pe=m.querySelector('[data-pend]');if(pe)pe.textContent=Math.max(0,Math.round(pHp));}
    function lunge(w){var f=w==='p'?pFighter:eFighter,c=w==='p'?'lunge-p':'lunge-e';f.classList.remove(c);void f.offsetWidth;f.classList.add(c);}
    function hitR(f){f.classList.remove('hit');void f.offsetWidth;f.classList.add('hit');setTimeout(function(){f.classList.remove('hit')},320);}
    function ft(target,text,cls){var s=fx.getBoundingClientRect(),t=target.getBoundingClientRect();var el=document.createElement('div');el.className='dmg-num '+cls;el.textContent=text;el.style.left=(t.left-s.left+t.width/2)+'px';el.style.top=(t.top-s.top+t.height*.18)+'px';fx.appendChild(el);setTimeout(function(){el.remove()},950);}
    function spawnParticles(target,n){var s=fx.getBoundingClientRect(),t=target.getBoundingClientRect(),cx=t.left-s.left+t.width/2,cy=t.top-s.top+t.height/2;for(var j=0;j<n;j++){var el=document.createElement('div');el.className='particle';var a=Math.random()*Math.PI*2,d=20+Math.random()*36;el.style.left=cx+'px';el.style.top=cy+'px';el.style.setProperty('--tx',Math.cos(a)*d+'px');el.style.setProperty('--ty',Math.sin(a)*d+'px');fx.appendChild(el);setTimeout(function(){el.remove()},650);}}
    function castSkill(){castCount++;pAura.classList.add('on');banner.classList.remove('show');void banner.offsetWidth;banner.classList.add('show');if(S&&S.getEnabled())S.play('skill');var s=fx.getBoundingClientRect(),tp=pFighter.getBoundingClientRect(),te=eFighter.getBoundingClientRect();var cx=tp.left-s.left+tp.width/2,cy=tp.top-s.top+tp.height*.4;var dx=te.left-s.left+te.width/2-cx,dy=te.top-s.top+te.height*.4-cy;var el=document.createElement('div');el.className='projectile';el.style.left=cx+'px';el.style.top=cy+'px';el.style.setProperty('--dx',dx+'px');el.style.setProperty('--dy',dy+'px');el.style.setProperty('--proj',aura);el.innerHTML=A.projectileSVG(techEl);fx.appendChild(el);el.classList.add('go');el.addEventListener('animationend',function(){el.remove();var im=document.createElement('div');im.className='impact';im.style.left=(cx+dx)+'px';im.style.top=(cy+dy)+'px';im.style.setProperty('--proj',aura);fx.appendChild(im);setTimeout(function(){im.remove()},400);});setTimeout(function(){pAura.classList.remove('on')},1100);}
    function finish(){pHp=res.pHp;eHp=res.eHp;sh();var rw=m.querySelector('.combat-reward');if(rw)rw.style.display='';var ok=m.querySelector('#cb-ok');if(ok)ok.style.display='';if(seal){seal.style.display='';void seal.offsetWidth;seal.querySelector('span').style.animation='none';void seal.querySelector('span').offsetWidth;seal.querySelector('span').style.animation='sealStamp .5s cubic-bezier(.2,1.4,.4,1) forwards';}if(S&&S.getEnabled())S.play(res.win?'win':'lose');}
    function step(){if(!stage.isConnected)return;if(i>=log.length){finish();return}var e=log[i];if(e.side==='p'&&(i===0||i%6===5))castSkill();if(!phased&&lv.boss&&eHp/eHp0<=.5){phased=true;stage.classList.add('phase2');banner.textContent='【二阶段】· 暴怒';banner.classList.remove('show');void banner.offsetWidth;banner.classList.add('show');setTimeout(function(){banner.textContent='施放 · 暴怒';},1200);if(S&&S.getEnabled())S.play('skill');}
    if(e.side==='p'){if(e.miss){ft(eFighter,'闪避','miss');lunge('p');}else{eHp=Math.max(0,eHp-e.dmg);sh();lunge('p');hitR(eFighter);ft(eFighter,'-'+e.dmg+(e.crit?' 暴击!':''),e.crit?'crit':'dmg');spawnParticles(eFighter,e.crit?12:7);if(e.crit){stage.classList.remove('crit');void stage.offsetWidth;stage.classList.add('crit');if(S&&S.getEnabled())S.play('crit');}else if(S&&S.getEnabled())S.play('hit');}}
    else{if(e.miss){ft(pFighter,'闪避','miss');lunge('e');}else{pHp=Math.max(0,pHp-e.dmg);sh();lunge('e');hitR(pFighter);ft(pFighter,'-'+e.dmg+(e.crit?' 暴击!':''),e.crit?'crit':'dmg');spawnParticles(pFighter,e.crit?12:7);if(e.crit){stage.classList.remove('crit');void stage.offsetWidth;stage.classList.add('crit');if(S&&S.getEnabled())S.play('crit');}else if(S&&S.getEnabled())S.play('hit');}}
    i++;setTimeout(step,delay);}
    setTimeout(step,250);
  }

  /* ---------------- 法宝 ---------------- */
  function renderTreasure() {
    const s = Game.state;
    const slots = [
      { key: 'weapon', name: '本命法宝', icon: '🗡️' },
      { key: 'armor', name: '护身法宝', icon: '🛡️' },
      { key: 'trinket', name: '辅助法宝', icon: '💍' }
    ];
    const slotHtml = slots.map(sl => {
      const tid = s.equipped[sl.key];
      if (tid) {
        const t = Game.TREASURES.find(x => x.id === tid); const ts = Game.treasureStats(tid);
        return `<div class="slot filled">${t.icon}<div class="sl"><div class="sn">${t.name} <span class="q" style="color:${qColor(t.quality)}">${qName(t.quality)}</span></div><div class="sd">${attrText(ts.attrs)} · ${ts.level}级</div></div></div>`;
      }
      return `<div class="slot empty">${sl.icon}<div class="sl"><div class="sn">${sl.name}</div><div class="sd">未装备</div></div></div>`;
    }).join('');
    const inv = Game.TREASURES.map(t => {
      const own = s.treasures[t.id]; const owned = own && own.count > 0;
      if (!owned) return `<div class="tcard locked"><div class="ti">❔</div><div class="tn">未获得</div><div class="td">${slotName(t.slot)}</div></div>`;
      const ts = Game.treasureStats(t.id); const cost = Game.enhanceCost(t.id);
      const maxed = own.level >= CONFIG.treasure.maxLevel;
      const enhAfford = !maxed && s.materials >= cost.mat && s.stone >= cost.stone;
      const smeltAfford = own.count >= 2;
      const equipped = s.equipped[t.slot] === t.id;
      const enhBtn = maxed ? `<button class="buy-btn maxed" disabled>圆满</button>`
        : `<button class="buy-btn" data-enh="${t.id}" ${enhAfford ? '' : 'disabled'}>强化<div class="price">${cost.mat}🌿 ${Game.formatNum(cost.stone)}💎</div></button>`;
      const eqBtn = equipped ? `<button class="buy-btn eq" data-unequip="${t.slot}">卸下</button>`
        : `<button class="buy-btn" data-equip="${t.id}">装备</button>`;
      const smeltBtn = smeltAfford ? `<button class="buy-btn smelt" data-smelt="${t.id}">熔炼<div class="price">+${CONFIG.treasure.smeltMatPerQuality * t.quality}🌿</div></button>` : '';
      return `<div class="tcard">
        <div class="ti" style="color:${qColor(t.quality)}">${t.icon}</div>
        <div class="tn">${t.name} <span class="q" style="color:${qColor(t.quality)}">${qName(t.quality)}</span></div>
        <div class="td">${t.desc}</div>
        <div class="tattrs">${attrText(ts.attrs)}</div>
        <div class="tsub">持有 ${own.count} · ${own.level}级</div>
        <div class="tactions">${eqBtn}${enhBtn}${smeltBtn}</div>
      </div>`;
    }).join('');
    view.innerHTML = `
      <div class="section-title">💎 法宝 <small>获取/装备/强化/熔炼，撑起战力</small></div>
      <div class="res-bar"><div class="res-chip mat"><div class="l">天材地宝</div><div class="v">🌿 ${Game.formatNum(s.materials)}</div></div><div class="res-chip"><div class="l">灵石</div><div class="v">💎 ${Game.formatNum(s.stone)}</div></div></div>
      <div class="battle-meta"><details><summary>🧘 强化后战斗属性预览 (点击展开)</summary>
        <div class="player-panel" style="margin-top:8px">
          <div class="pp-head">🧘 自身战力 <b>${Game.formatNum(Game.combatStats().power)}</b></div>
          <div class="pp-stats">
            <span>攻 ${Game.combatStats().atk}</span><span>防 ${Game.combatStats().def}</span><span>气血 ${Game.combatStats().hp}</span>
            <span>命中 ${Math.round(Game.combatStats().hit * 100)}%</span><span>闪避 ${Math.round(Game.combatStats().dodge * 100)}%</span><span>暴击 ${Math.round(Game.combatStats().crit * 100)}%</span>
          </div>
        </div></details>
      </div>
      <div class="hint">🌿 <b>天材地宝</b>：强化法宝（每件耗 🌿+💎，随等级与品质递增）、喂养灵宠的必需素材；盈余法宝可<b>熔炼</b>返还天材地宝。掉落于战斗/秘境/奇遇，寻妖重复收服亦赠。</div>
      <div class="slot-row">${slotHtml}</div>
      <div class="section-title sub">法宝囊</div>
      <div class="treasure-grid">${inv}</div>`;
    view.querySelectorAll('[data-equip]').forEach(b => b.addEventListener('click', () => { if (Game.equipTreasure(b.dataset.equip)) renderTreasure(); else toast('无法装备'); }));
    view.querySelectorAll('[data-unequip]').forEach(b => b.addEventListener('click', () => { Game.unequip(b.dataset.unequip); renderTreasure(); }));
    view.querySelectorAll('[data-enh]').forEach(b => b.addEventListener('click', () => { if (Game.enhanceTreasure(b.dataset.enh)) renderTreasure(); else toast('材料或灵石不足'); }));
    view.querySelectorAll('[data-smelt]').forEach(b => b.addEventListener('click', () => { if (Game.smeltTreasure(b.dataset.smelt)) renderTreasure(); else toast('至少需要 2 件方可熔炼'); }));
  }

  /* ---------------- 购买委托 ---------------- */
  function bindBuy(type) {
    view.querySelectorAll('[data-buy]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.id; let ok = false;
        if (type === 'technique') ok = Game.buyTechnique(id);
        else if (type === 'abode') ok = Game.buyAbode(id);
        else if (type === 'pill') ok = Game.takePill(id);
        if (ok) renderCurrent(); else toast('灵石不足');
      });
    });
  }

  function renderCurrent() {
    switch (currentTab) {
      case 'cultivate': renderCultivate(); break;
      case 'technique': renderTechniques(); break;
      case 'abode': renderAbodes(); break;
      case 'pill': renderPills(); break;
      case 'pet': renderPet(); break;
      case 'secret': renderSecret(); break;
      case 'insight': renderInsight(); break;
      case 'fly': renderFly(); break;
      case 'battle': renderBattle(); break;
      case 'treasure': renderTreasure(); break;
      case 'event': renderEvents(); break;
      case 'achv': renderAchievements(); break;
      case 'setting': renderSettings(); break;
    }
  }
  function switchTab(tab) {
    currentTab = tab;
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
    renderCurrent(); view.scrollTop = 0;
  }

  /* ---------------- 弹窗 ---------------- */
  function showTribulation(realmName, success) {
    const m = modal(`
      <div class="trib-glow"></div>
      <div class="trib">${success ? '⚡' : '💥'}</div>
      <h2>${success ? '渡劫飞升' : '渡劫失败'}</h2>
      <p>${success ? `天雷滚滚，道心如铁……` : `道心受创，修为折损。`}</p>
      <p class="big">${success ? `晋入 ${realmName}！` : '再凝道果，卷土重来'}</p>
      <button class="btn" id="trib-ok">顺应天命</button>`, 'tribulation');
    const close = () => closeModal(m);
    $('#trib-ok').addEventListener('click', close);
    setTimeout(close, success ? 2600 : 2000);
  }
  function showOffline(off) {
    modal(`<h2>🧘 出关</h2><p>你闭关 <b>${Game.formatTime(off.sec)}</b>，灵机未断。</p>
      <p>修为 +<span class="big">${Game.formatNum(off.xp)}</span></p>
      <p>灵石 +<span class="big">${Game.formatNum(off.stone)}</span></p>
      <button class="btn" id="off-ok">检阅道果</button>`);
    $('#off-ok').addEventListener('click', () => closeModal($('#modal-layer .modal-mask')));
  }
  function showRootPicker() {
    const grid = Game.ROOTS.map(r => `<div class="root-card" data-root="${r.id}"><div class="ic">${r.icon}</div><div class="nm">${r.name}</div><div class="ds">${r.desc}</div></div>`).join('');
    const m = modal(`<h2>🌟 觉醒灵根</h2><p>灵根既定，影响一身道途，慎重抉择（永久）。</p><div class="root-grid" style="margin-top:14px">${grid}</div>`, 'tribulation');
    m.querySelectorAll('[data-root]').forEach(c => c.addEventListener('click', () => {
      Game.setRoot(c.dataset.root); closeModal(m);
      const r = Game.ROOTS.find(x => x.id === c.dataset.root);
      toast(`觉醒${r.name}！`, true);
    }));
  }
  function showReincarnate(gain) {
    modal(`<h2>🔁 飞升转世</h2><p>你斩断此世因果，重入轮回。</p><p>得仙缘 <span class="big">+${gain}</span></p><p>全局效率 +${Math.round(gain * CONFIG.legacyPerPoint * 100)}%，翌世愈发强盛。</p><button class="btn" id="ri-ok">再启道途</button>`);
    $('#ri-ok').addEventListener('click', () => closeModal($('#modal-layer .modal-mask')));
  }

  /* ---------------- 事件订阅 ---------------- */
  Game.on('break', (d) => {
    if (d.major) showTribulation(d.realm, d.success);
    else toast('破境成功，修为更进', true);
    renderCurrent();
  });
  Game.on('achievement', (a) => { toast(`🏆 解锁成就：${a.name}`, true); if (currentTab === 'achv') renderAchievements(); });
  Game.on('event', () => { if (currentTab === 'event') renderEvents(); });
  Game.on('pills', () => { if (currentTab === 'cultivate' || currentTab === 'pill') renderCurrent(); });
  Game.on('root', () => {});
  Game.on('pet', () => { if (currentTab === 'pet') renderCurrent(); });
  Game.on('explore', () => { if (currentTab === 'secret') renderCurrent(); });
  Game.on('insight', () => { if (currentTab === 'insight') renderCurrent(); });
  Game.on('reincarnate', (d) => { showReincarnate(d.gain); renderCurrent(); });
  Game.on('reset', () => { updateTopbar(); });

  /* ---------------- 启动 ---------------- */
  function init() {
    const offline = Game.start();
    if (window.SFX) window.SFX.setEnabled(!!Game.state.sfx);
    document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => switchTab(t.dataset.tab)));
    switchTab('cultivate');
    updateTopbar();
    if (offline) showOffline(offline);
    if (!Game.state.rootId) showRootPicker();
    function loop() { updateTopbar(); requestAnimationFrame(loop); }
    requestAnimationFrame(loop);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
